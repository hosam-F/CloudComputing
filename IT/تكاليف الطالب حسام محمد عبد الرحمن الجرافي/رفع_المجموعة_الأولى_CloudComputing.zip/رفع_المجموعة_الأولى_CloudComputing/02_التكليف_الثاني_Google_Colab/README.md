# التكليف الثاني: Google Colab

المطلوب إنشاء مشروع جديد في Colab، تشغيل برنامج Python بسيط، ربط Colab بـ Google Drive واستعراض ملف أو مجلد، ثم فتح أو سحب مشروع Colab منشور على GitHub والعمل عليه.

يحتوي `assignment2_colab_demo.ipynb` على الخلايا السابقة الخاصة بـ Python وDrive، وأضيفت إليه خلية GitHub لسحب مستودع `googlecolab/colabtools` وفتح الدفتر العام `colab_intro.ipynb`.

للتنفيذ: افتح الدفتر في Colab، شغّل الخلايا بالترتيب، وافق على ربط Drive عند الطلب، ثم شغّل خلية GitHub. حفظ نسخة شخصية باستخدام **Fork** يحتاج تسجيل الدخول إلى GitHub، ولذلك ينفذه الطالب يدويًا إذا طلبه الدكتور.

يُستخدم `assignment2_video_script.md` كسيناريو قصير أثناء تسجيل الشاشة، ويحتوي `assignment2_sources.md` على الروابط المرجعية.
