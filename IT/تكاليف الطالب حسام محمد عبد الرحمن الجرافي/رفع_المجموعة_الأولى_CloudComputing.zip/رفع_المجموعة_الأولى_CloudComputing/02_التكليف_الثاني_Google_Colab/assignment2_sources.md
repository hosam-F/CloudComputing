# مصادر التكليف الثاني: Google Colab وGitHub

## مصدر Google الرسمي
- Google Colab: https://developers.google.com/colab
- يصف Colab بأنه خدمة Jupyter مستضافة لا تحتاج إلى إعداد محلي، وتوفر بيئة تشغيل جاهزة، وتعاونًا ومشاركة، واتصالًا بـ Google Drive.

## مصدر GitHub الرسمي لمكتبات Colab
- https://github.com/googlecolab/colabtools
- مستودع رسمي لمنظمة Google Colab، ويحتوي على مكتبات Python والموارد المرتبطة بـ Colab. يمكن استخدامه كمشروع منشور على GitHub للتكليف.

## صفحة فتح مستودعات GitHub في Colab
- https://colab.research.google.com/github
- تتيح البحث عن دفاتر Jupyter المنشورة في GitHub وفتحها في Colab.

## اختيار المشروع للتكليف
سيُستخدم مستودع Google الرسمي googlecolab/colabtools، مع فتح ملف Notebook من مجلد notebooks عبر Colab. هذا الاختيار مناسب لأنه منشور رسميًا، واضح الصلة بـ Colab، ولا يحتاج إلى بطاقة دفع.
