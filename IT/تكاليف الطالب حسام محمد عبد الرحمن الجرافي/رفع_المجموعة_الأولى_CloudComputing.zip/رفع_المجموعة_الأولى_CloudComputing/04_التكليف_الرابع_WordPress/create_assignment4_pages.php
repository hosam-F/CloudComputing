<?php
require_once __DIR__ . '/Cloud_Computing_Assignment_5/wp-load.php';
if (!function_exists('wp_insert_post')) { exit('WordPress not loaded'); }
$pages = [
 ['title'=>'حول النظام','slug'=>'about-system','content'=>'<h2>حول دليل المربي القرآني</h2><p>هذا موقع تعليمي مصغر يوضح استخدام WordPress في بناء صفحات مترابطة وإدارة بيانات الطلاب محليًا. أُنجز الموقع ضمن مقرر الحوسبة السحابية للطالب حسام محمد عبد الرحمن الجرافي.</p><p><a href="'.esc_url(home_url('/?page_id=6')).'">انتقل إلى صفحة إضافة طالب</a> | <a href="'.esc_url(home_url('/?page_id=7')).'">انتقل إلى صفحة بيانات الطلاب</a></p>'],
 ['title'=>'دليل الاستخدام','slug'=>'user-guide','content'=>'<h2>دليل استخدام الموقع</h2><ol><li>افتح صفحة إضافة طالب وأدخل رقم الطالب واسمه والعمر.</li><li>أكمل المرحلة والمجموعة ومستوى القراءة والحفظ والملاحظات ثم اضغط إضافة الطالب.</li><li>افتح صفحة بيانات الطلاب لمراجعة السجلات.</li><li>استخدم تعديل لتحديث سجل، أو حذف لإزالته بعد التأكد.</li></ol><p><a href="'.esc_url(home_url('/?page_id=6')).'">إضافة طالب</a> | <a href="'.esc_url(home_url('/?page_id=7')).'">بيانات الطلاب</a> | <a href="'.esc_url(home_url('/?page_id=4')).'">مثال على صفحة</a></p>']
];
$ids=[];
foreach($pages as $p){$existing=get_page_by_path($p['slug'],OBJECT,'page');if($existing){$ids[]=$existing->ID;continue;}$ids[]=wp_insert_post(['post_title'=>$p['title'],'post_name'=>$p['slug'],'post_content'=>$p['content'],'post_status'=>'publish','post_type'=>'page']);}
$hub=get_page_by_path('example-page',OBJECT,'page');
if(!$hub){$hub=get_page_by_title('مثال على صفحة',OBJECT,'page');}
if($hub){$links='<h2>صفحات التكليف الرابع</h2><p>يمكن التنقل بين الصفحات الخمس التالية:</p><ul><li><a href="'.esc_url(home_url('/?page_id=6')).'">إضافة طالب</a></li><li><a href="'.esc_url(home_url('/?page_id=7')).'">بيانات الطلاب</a></li><li><a href="'.esc_url(home_url('/?page_id=4')).'">مثال على صفحة</a></li>';foreach($ids as $id){$links.='<li><a href="'.esc_url(get_permalink($id)).'">'.esc_html(get_the_title($id)).'</a></li>';}$links.='</ul><p>هذه الصفحات مترابطة وتوضح مفهوم الموقع متعدد الصفحات في WordPress.</p>';wp_update_post(['ID'=>$hub->ID,'post_content'=>$links]);}
echo 'created_pages='.implode(',',array_map('intval',$ids));
